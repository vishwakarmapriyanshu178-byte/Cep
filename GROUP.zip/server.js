const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
const path = require("path");

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "YOUR_MYSQL_PASSWORD",
  database: "smart_classroom"
});

db.connect(err => {
  if (err) {
    console.error("MySQL connection failed:", err.message);
    return;
  }
  console.log("MySQL connected successfully.");
});

app.post("/api/register", (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ message: "All fields are required." });
  }

  const sql = "INSERT INTO students (name, email, password) VALUES (?, ?, ?)";
  db.query(sql, [name, email, password], (err) => {
    if (err) {
      if (err.code === "ER_DUP_ENTRY") {
        return res.status(400).json({ message: "Email already registered." });
      }
      return res.status(500).json({ message: "Database error." });
    }
    res.json({ message: "Registration successful." });
  });
});

app.post("/api/login", (req, res) => {
  const { email, password } = req.body;
  const sql = "SELECT id, name, email FROM students WHERE email = ? AND password = ?";
  db.query(sql, [email, password], (err, rows) => {
    if (err) return res.status(500).json({ message: "Database error." });
    if (!rows.length) return res.status(401).json({ message: "Invalid email or password." });
    res.json({ message: "Login successful.", student: rows[0] });
  });
});

app.post("/api/feedback", (req, res) => {
  const { student_name, message } = req.body;
  if (!student_name || !message) {
    return res.status(400).json({ message: "Please fill all fields." });
  }

  db.query(
    "INSERT INTO feedback (student_name, message) VALUES (?, ?)",
    [student_name, message],
    err => {
      if (err) return res.status(500).json({ message: "Could not save feedback." });
      res.json({ message: "Feedback submitted successfully." });
    }
  );
});

app.get("/api/students", (req, res) => {
  db.query(
    "SELECT id, name, email, created_at FROM students ORDER BY id DESC",
    (err, rows) => {
      if (err) return res.status(500).json({ message: "Database error." });
      res.json(rows);
    }
  );
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`Smart Classroom running at http://localhost:${PORT}`);
});
