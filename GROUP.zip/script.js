
function checkLogin() {

    const loggedIn =
        localStorage.getItem("smartClassLoggedIn");

    const currentPage =
        window.location.pathname
            .split("/")
            .pop()
            .toLowerCase();

    const publicPages = [
        "",
        "login.html"
    ];

    // User is not logged in
    if (
        !publicPages.includes(currentPage) &&
        loggedIn !== "true"
    ) {
        window.location.href = "login.html";
        return;
    }

    // Already logged in
    if (
        loggedIn === "true" &&
        currentPage === "login.html"
    ) {
        window.location.href = "index.html";
    }
}

checkLogin();




function toggleMenu() {

    const nav =
        document.querySelector(".nav-links");

    if (nav) {
        nav.classList.toggle("show");
    }
}




const loginForm =
    document.getElementById("loginForm");

if (loginForm) {

    loginForm.addEventListener(
        "submit",
        function(event) {

            event.preventDefault();

            const email =
                document
                    .getElementById("loginEmail")
                    .value
                    .trim()
                    .toLowerCase();

            const password =
                document
                    .getElementById("loginPassword")
                    .value
                    .trim();

            const message =
                document.getElementById("loginMessage");


            const correctEmail =
                "admin@gmail.com";

            const correctPassword =
                "1234";

            if (
                email === correctEmail &&
                password === correctPassword
            ) {

                localStorage.setItem(
                    "smartClassLoggedIn",
                    "true"
                );

                localStorage.setItem(
                    "smartClassCurrentUser",
                    email
                );

                const remember =
                    document.getElementById("remember");

                if (
                    remember &&
                    remember.checked
                ) {
                    localStorage.setItem(
                        "smartClassRemember",
                        "true"
                    );
                }

                if (message) {

                    message.textContent =
                        "✓ Login successful!";

                    message.style.color =
                        "#16a34a";
                }

                setTimeout(function() {

                    window.location.href =
                        "index.html";

                }, 700);

            } else {

                if (message) {

                    message.textContent =
                        "✕ Invalid email or password.";

                    message.style.color =
                        "#dc2626";
                }
            }
        }
    );
}




function forgotPassword(event) {

    if (event) {
        event.preventDefault();
    }

    alert(
        "SmartClass Login Details\n\n" +
        "Email: admin@gmail.com\n" +
        "Password: 1234"
    );
}


if (true) {
    
}

function confirmLogout() {

    localStorage.removeItem(
        "smartClassLoggedIn"
    );

    localStorage.removeItem(
        "smartClassCurrentUser"
    );

    localStorage.removeItem(
        "smartClassRemember"
    );

    const message =
        document.getElementById("logoutMessage");

    if (message) {

        message.textContent =
            "✓ Logout successful! Redirecting...";

        message.style.color =
            "#16a34a";
    }

    setTimeout(function() {

        window.location.href =
            "login.html";

    }, 800);
}




const classForm =
    document.getElementById("classForm");


function updateDashboard(data) {

    const displayClass =
        document.getElementById("displayClass");

    if (!displayClass) {
        return;
    }

    displayClass.textContent =
        data.className || "Your classroom";


    const displayTeacher =
        document.getElementById("displayTeacher");

    if (displayTeacher) {

        displayTeacher.textContent =
            data.teacher
                ? "Teacher: " + data.teacher
                : "Teacher information will appear here.";
    }


    const displayStudents =
        document.getElementById("displayStudents");

    if (displayStudents) {

        displayStudents.textContent =
            data.students || "0";
    }


    const displayTech =
        document.getElementById("displayTech");

    if (displayTech) {

        displayTech.textContent =
            data.technology || "—";
    }


    const displayTopic =
        document.getElementById("displayTopic");

    if (displayTopic) {

        displayTopic.textContent =
            data.topic || "No topic added";
    }
}



if (classForm) {

    const saved =
        JSON.parse(
            localStorage.getItem(
                "smartClassroom"
            ) || "null"
        );

    if (saved) {

        const teacher =
            document.getElementById("teacher");

        const className =
            document.getElementById("className");

        const students =
            document.getElementById("students");

        const technology =
            document.getElementById("technology");

        const topic =
            document.getElementById("topic");


        if (teacher) {
            teacher.value =
                saved.teacher || "";
        }

        if (className) {
            className.value =
                saved.className || "";
        }

        if (students) {
            students.value =
                saved.students || "";
        }

        if (technology) {
            technology.value =
                saved.technology || "";
        }

        if (topic) {
            topic.value =
                saved.topic || "";
        }

        updateDashboard(saved);
    }


    classForm.addEventListener(
        "submit",
        function(event) {

            event.preventDefault();

            const teacher =
                document.getElementById("teacher");

            const className =
                document.getElementById("className");

            const students =
                document.getElementById("students");

            const technology =
                document.getElementById("technology");

            const topic =
                document.getElementById("topic");


            const data = {

                teacher:
                    teacher ? teacher.value.trim() : "",

                className:
                    className ? className.value.trim() : "",

                students:
                    students ? students.value : "",

                technology:
                    technology ? technology.value : "",

                topic:
                    topic ? topic.value.trim() : ""
            };


            localStorage.setItem(
                "smartClassroom",
                JSON.stringify(data)
            );


            updateDashboard(data);


            const message =
                document.getElementById(
                    "formMessage"
                );

            if (message) {

                message.textContent =
                    "✓ Classroom details saved successfully!";

                message.style.color =
                    "#16a34a";
            }
        }
    );
}




function clearClassroom() {

    localStorage.removeItem(
        "smartClassroom"
    );

    if (classForm) {
        classForm.reset();
    }

    updateDashboard({});

    const message =
        document.getElementById(
            "formMessage"
        );

    if (message) {

        message.textContent =
            "Classroom details cleared.";

        message.style.color =
            "#dc2626";
    }
}




const contactForm =
    document.getElementById(
        "contactForm"
    );


if (contactForm) {

    contactForm.addEventListener(
        "submit",
        function(event) {

            event.preventDefault();

            const contact = {

                name:
                    document
                        .getElementById("contactName")
                        .value
                        .trim(),

                email:
                    document
                        .getElementById("contactEmail")
                        .value
                        .trim(),

                subject:
                    document
                        .getElementById("contactSubject")
                        .value
                        .trim(),

                rating:
                    document
                        .getElementById("rating")
                        .value,

                message:
                    document
                        .getElementById("contactMessage")
                        .value
                        .trim(),

                date:
                    new Date().toLocaleString()
            };


            // Save contact + feedback
            localStorage.setItem(
                "smartClassContact",
                JSON.stringify(contact)
            );


            const response =
                document.getElementById(
                    "contactResponse"
                );


            if (response) {

                response.textContent =
                    "✓ Thank you! Your message and feedback have been submitted successfully.";

                response.style.color =
                    "#16a34a";
            }


            contactForm.reset();
        }
    );
}




function showCurrentUser() {

    const userElement =
        document.getElementById(
            "currentUser"
        );

    if (!userElement) {
        return;
    }

    const email =
        localStorage.getItem(
            "smartClassCurrentUser"
        );

    userElement.textContent =
        email || "Admin";
}

showCurrentUser();




document
    .querySelectorAll(".nav-links a")
    .forEach(function(link) {

        link.addEventListener(
            "click",
            function() {

                const nav =
                    document.querySelector(
                        ".nav-links"
                    );

                if (nav) {

                    nav.classList.remove(
                        "show"
                    );
                }
            }
        );
    });


